Original CC0 reading passages and questions. Synthetic acceptance material, not an official SAT test. No external content or assets.
