Original CC0 SATchi software fixture. Colored tiles are intentionally synthetic.
